# Allow user to input their First Name and assign that input to a variable
firstname = input("What is your first name? ")

# Allow user to input their Last Name and assign that input to a variable
lastname = input("What is your last name? ")

# Print a welcome message that includes the user's First Name and Last Name using the variables.
print('Welcome,', firstname, lastname,'!')

