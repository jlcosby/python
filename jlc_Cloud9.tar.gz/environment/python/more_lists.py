import random
#1 create list
new_var=[ ]

#print(type(new_var), new_var)

#2 list 1-100
numbers = list(range(1-100))

#print(numbers)

#3 reverse
#numbers.reverse()

#print (numbers)

#4 random shuffle
#random.shuffle(numbers)

#print(numbers)

#5 sort
#numbers.sort()

#print(numbers)

#5 index
#index = numbers.index(7)

#print(numbers[index])

#6 iterate through list
for number in numbers:
    #print(number)
    new_var.append(number**2)
    #print(number **2)
    #print(new_var)   

#7 list comprehension
numbers_squared = [number ** 2 for number in numbers] 

#print(numbers_squared)

numbers_squared_odd = [number ** 2 for number in numbers if number % 2 == 1]

#print(numbers_squared_odd)

#8 random list numbers - finding max value

rand_numbers = [random.randint(0,1000) for i in range(random.randint(1, 100))]

print(rand_numbers)

max_val = -1

for number in rand_numbers:
    if number > max_val:
        max_val = number

print (max_val)

rand_numbers.sort()

print(rand_numbers[-2])
