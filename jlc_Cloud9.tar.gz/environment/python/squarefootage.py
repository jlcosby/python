#enter the variables for the width and length of the room in feet
length=float(input("What is the length of the room in feet? "))
width=float(input("What is the width of the room in feet? "))

#formula for area
area=length*width

#message
print("The area of the room is",area, "sq. ft")
